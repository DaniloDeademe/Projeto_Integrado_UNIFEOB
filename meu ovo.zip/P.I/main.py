from menus.menuprincipal import MenuPrincipal


if __name__ == "__main__":
    MenuPrincipal() 

